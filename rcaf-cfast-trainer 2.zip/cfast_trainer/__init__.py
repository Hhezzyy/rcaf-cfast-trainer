﻿"""RCAF CFAST Trainer (offline-first).

Core deterministic logic and pygame adapters will be added in later tasks.
"""
