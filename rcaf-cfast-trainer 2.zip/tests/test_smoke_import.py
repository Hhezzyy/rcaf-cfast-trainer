﻿def test_import_package() -> None:
    import cfast_trainer  # noqa: F401
